#!/bin/bash

echo "Installing node v4 for mediators..."
. /home/openhim/.nvm/nvm.sh
nvm install 4
echo "Done."
